﻿using UnityEngine;
using System.Collections;

public class WormFood : MonoBehaviour {

	public int FoodCount = 0;
	
	void Start () 
	{
	
	}

	void OnTriggerEnter (Collider other) 
	{
		FoodParticle FP = other.gameObject.GetComponent<FoodParticle> ();
		if (FP != null) 
		{
			FP.WasEaten ();
		}



	}
	
	void Update () 
	{
	
	}
}
