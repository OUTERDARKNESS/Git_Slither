﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class WormControl : MonoBehaviour {



	float input_Horz = 0;
	float input_Vert = 0;

	public float Speed = 1;
	public float RotMult = 10;
	public Vector3 MoveDir;
	public Vector3 CurPos;
	public Vector3 LastPos;


	public Transform SteerGO;
	public Transform SteerTargGO;

	public GameObject SegPrefab;

	public int SegCount = 5;
	List<Vector3> HeadPosList = new List<Vector3>();
	public List<Transform> SegList = new List<Transform>();
	public float SegDist = 0.3333f;



	void Start () 
	{
		LastPos = transform.position;
		Update_SegCount ();

		for (int i = 0; i < SegCount + 2; i++) 
		{
			HeadPosList.Add (Vector3.zero);
			//FoodCount += SegCount;
		}

	}
	
	
	void Update () 
	{
		if (Time.time < 0.2f) {return;}

		Update_UserInput ();
		Update_Movement ();
		Update_HeadPos ();
		Update_SegPos ();
	}


	void Update_UserInput()
	{
		input_Horz = Input.GetAxis ("Horizontal");
		input_Vert = Input.GetAxis ("Vertical");
	}


	void Update_Movement()
	{


		CurPos = transform.position;


		MoveDir = transform.localEulerAngles;

		MoveDir.y += Time.deltaTime * input_Horz * RotMult;
		//transform.rotation = new Quaternion (0, input_Horz, input_Vert, 1);

		transform.localEulerAngles = MoveDir;


		CurPos = Vector3.MoveTowards(CurPos, SteerTargGO.position, Time.deltaTime * Speed);
		transform.position = CurPos;


	}



	void Update_HeadPos()
	{
		float dist = Vector3.Distance (transform.position, LastPos);
		if (dist > SegDist) 
		{
			HeadPosList.Add (transform.position);
			if (HeadPosList.Count > (SegCount + 5)) 
			{
				HeadPosList.RemoveAt (0);
			}
			LastPos = transform.position;
		}
	}


	void Update_SegPos()
	{
		for (int i = 0; i < SegList.Count; i++) 
		{
			//Debug.Log ("i=" + i + "  @: " + Time.frameCount);
			SegList [i].transform.position = HeadPosList [HeadPosList.Count - 1 - i];

		}
	}
		
	void Update_SegCount()
	{
		while(SegList.Count < SegCount) 
		{
			GameObject GO = GameObject.Instantiate (SegPrefab);
			GO.name = GO.name + SegCount;
			SegList.Add (GO.transform);
		}
	}
	//LastPos = transform.position;



	void OnGUI () 
	{
		GUILayout.Box ("H: " + input_Horz);
		GUILayout.Box ("V: " + input_Vert);
	}









}
