﻿using UnityEngine;
using System.Collections;

namespace Worm
{
	public class MovementController : MonoBehaviour
	{
		public void Update_Movement(float input_Horizontal, float InputSpeed, Transform SteerTargGO, float Speed)
		{
			float InputSpeedMultiplier = 10;
			float RotationMultiplier = 300;

			Vector3 CurPos = transform.position;

			Vector3 MoveDir = transform.localEulerAngles;
			MoveDir.y += Time.deltaTime * input_Horizontal * RotationMultiplier;

			transform.localEulerAngles = MoveDir;

			CurPos = Vector3.MoveTowards(CurPos, SteerTargGO.position, (Time.deltaTime * Speed) + (InputSpeed * InputSpeedMultiplier * Time.deltaTime));
			transform.position = CurPos;
		}
	}
}