﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace Worm
{
	public class SegmentController : MonoBehaviour
	{
		public float TotalCalorie;
		public Vector3 LastPos;
		public Transform SteerTargGO;
		public GameObject SegPrefab;
		public int SegCount = 5;
		public float SpeedPenaltyMult = 2;
		public List<Transform> SegList = new List<Transform>();
		public float SegDist = 0.3333f;
		public int StartSegCount = 5;
		public List<Vector3> HeadPosList = new List<Vector3>();

		public void Update_SpeedPenalty(float InputSpeed)
		{
			if (InputSpeed > 0 && SegCount > StartSegCount) 
			{
				TotalCalorie -= Time.deltaTime * SpeedPenaltyMult;
				if (Mathf.CeilToInt (TotalCalorie) < SegCount) 
				{
					SegCount = Mathf.CeilToInt (TotalCalorie);
					Update_SegCount ();
				}
			} else {
				InputSpeed = 0;
			}
		}

		public void Update_HeadPos()
		{
			float dist = Vector3.Distance (transform.position, LastPos);
			if (dist > SegDist) 
			{
				HeadPosList.Add (transform.position);
				if (HeadPosList.Count > (SegCount + 500)) 
				{
					HeadPosList.RemoveAt (0);
				}
				LastPos = transform.position;
			}
		}

		public void Update_SegPos()
		{
			for (int i = 0; i < SegList.Count; i++) 
			{
				SegList [i].transform.position = HeadPosList [HeadPosList.Count - 1 - i];
			}
		}

		public void Update_SegCount()
		{
			while(SegList.Count < SegCount) 
			{
				GameObject GO = GameObject.Instantiate (SegPrefab);
				GO.name = GO.name + SegCount;
				SegList.Add (GO.transform);
			}

			for (int i = 0; i < SegList.Count; i++) 
			{
				SegList [i].gameObject.SetActive( (SegCount > i));
			}
		}
	}
}