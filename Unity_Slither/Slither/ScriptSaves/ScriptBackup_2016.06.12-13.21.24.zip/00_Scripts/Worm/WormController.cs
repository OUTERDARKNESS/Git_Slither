﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Food;

namespace Worm
{
	public class WormController : MonoBehaviour
	{
		public InputController inputController;
		public MovementController movementController;
		public SegmentController segmentController;

		public float Speed = 1;

		void Awake () 
		{
			AppData.bindToData (AppDataKeys.Food_Eaten, Food_EatenParticle_Handler);
		}

		void OnDestroy () 
		{
			AppData.unbindToData (AppDataKeys.Food_Eaten, Food_EatenParticle_Handler);
		}

		void Start () 
		{
			segmentController.StartSegCount = segmentController.SegCount;
			segmentController.TotalCalorie = (float)segmentController.SegCount;
			segmentController.LastPos = transform.position;
			segmentController.Update_SegCount ();

			for (int i = 0; i < segmentController.SegCount + 2; i++) 
			{
				segmentController.HeadPosList.Add (Vector3.zero);
			}
		}	

		void Update () 
		{
			if (Time.time < 0.2f) {return;}

			inputController.Update_UserInput ();

			segmentController.Update_SpeedPenalty (inputController.InputSpeed);
			movementController.Update_Movement (inputController.input_Horizontal, inputController.InputSpeed, segmentController.SteerTargGO.transform, Speed);
			segmentController.Update_HeadPos ();
			segmentController.Update_SegPos ();
		}

		void Food_EatenParticle_Handler (object val) 
		{
			FoodParticle FP = (FoodParticle)val;
			segmentController.SegCount += FP.Calories;

			segmentController.TotalCalorie = (float)segmentController.SegCount;
			segmentController.Update_SegCount ();
		}
	}
}