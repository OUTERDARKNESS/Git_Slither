using UnityEngine;
using System.Collections;

public class AppDataKeys : MonoBehaviour
{
	public const string Food_Eaten = "Food_Eaten";
}