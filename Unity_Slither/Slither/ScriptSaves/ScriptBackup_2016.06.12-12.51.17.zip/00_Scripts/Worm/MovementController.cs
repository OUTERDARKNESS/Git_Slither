﻿using UnityEngine;
using System.Collections;

namespace Worm
{
	public class MovementController : MonoBehaviour
	{
		public void sayHello()
		{
			Debug.Log ("hello from MovementController");
		}
	}
}