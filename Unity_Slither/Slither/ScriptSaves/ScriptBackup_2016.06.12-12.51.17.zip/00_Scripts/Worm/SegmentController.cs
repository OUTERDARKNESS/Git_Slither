﻿using UnityEngine;
using System.Collections;

namespace Worm
{
	public class SegmentController : MonoBehaviour
	{
		public void sayHello()
		{
			Debug.Log ("hello from SegmentController");
		}
	}
}