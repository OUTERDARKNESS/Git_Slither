﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class WormControl : MonoBehaviour
{
	float input_Horz = 0;
	float input_Vert = 0;

	public float Speed = 1;
	public float InputSpeed = 0;
	public float InputSpeedMult = 2;
	public float RotMult = 10;
	public Vector3 MoveDir;
	public Vector3 CurPos;
	public Vector3 LastPos;

	public Transform SteerGO;
	public Transform SteerTargGO;

	public GameObject SegPrefab;

	public int SegCount = 5;

	int StartSegCount = 5;
	float TotalCalorie;
	public float SpeedPenaltyMult = 2;
	List<Vector3> HeadPosList = new List<Vector3>();
	public List<Transform> SegList = new List<Transform>();
	public float SegDist = 0.3333f;

	void Awake () 
	{
		AppData.bindToData (ADkeys.Food_EatenParticle, Food_EatenParticle_Handler);
	}

	void OnDestroy () 
	{
		AppData.unbindToData (ADkeys.Food_EatenParticle, Food_EatenParticle_Handler);
	}

	void Start () 
	{
		StartSegCount = SegCount;
		TotalCalorie = (float)SegCount;
		LastPos = transform.position;
		Update_SegCount ();

		for (int i = 0; i < SegCount + 2; i++) 
		{
			HeadPosList.Add (Vector3.zero);
		}
	}	
	
	void Update () 
	{
		if (Time.time < 0.2f) {return;}

		Update_UserInput ();
		Update_Movement ();
		Update_HeadPos ();
		Update_SegPos ();
	}

	void Update_UserInput()
	{
		input_Horz = Input.GetAxis ("Horizontal");
		input_Vert = Input.GetAxis ("Vertical");
		InputSpeed = Input.GetAxis ("Boost");
	}

	void Update_Movement()
	{
		CurPos = transform.position;

		MoveDir = transform.localEulerAngles;
		MoveDir.y += Time.deltaTime * input_Horz * RotMult;

		transform.localEulerAngles = MoveDir;

		if (InputSpeed > 0 && SegCount > StartSegCount) 
		{
			Update_SpeedPenalty ();
		} else {
			InputSpeed = 0;
		}

		CurPos = Vector3.MoveTowards( CurPos, SteerTargGO.position, (Time.deltaTime * Speed) + (InputSpeed * InputSpeedMult * Time.deltaTime));
		transform.position = CurPos;
	}

	void Update_SpeedPenalty()
	{
		TotalCalorie -= Time.deltaTime * SpeedPenaltyMult;
		if (Mathf.CeilToInt (TotalCalorie) < SegCount) 
		{
			SegCount = Mathf.CeilToInt (TotalCalorie);
			Update_SegCount ();
		}
	}

	void Update_HeadPos()
	{
		float dist = Vector3.Distance (transform.position, LastPos);
		if (dist > SegDist) 
		{
			HeadPosList.Add (transform.position);
			if (HeadPosList.Count > (SegCount + 500)) 
			{
				HeadPosList.RemoveAt (0);
			}
			LastPos = transform.position;
		}
	}

	void Update_SegPos()
	{
		for (int i = 0; i < SegList.Count; i++) 
		{
			SegList [i].transform.position = HeadPosList [HeadPosList.Count - 1 - i];
		}
	}
		
	void Update_SegCount()
	{
		while(SegList.Count < SegCount) 
		{
			GameObject GO = GameObject.Instantiate (SegPrefab);
			GO.name = GO.name + SegCount;
			SegList.Add (GO.transform);
		}

		for (int i = 0; i < SegList.Count; i++) 
		{
			SegList [i].gameObject.SetActive( (SegCount > i));
		}
	}

	void OnGUI () 
	{
		GUILayout.Box ("InputSpeed: " + InputSpeed);
	}

	void Food_EatenParticle_Handler (object val) 
	{
		FoodParticle FP = (FoodParticle)val;
		SegCount += FP.Calories;

		TotalCalorie = (float)SegCount;
		Update_SegCount ();
	}
}