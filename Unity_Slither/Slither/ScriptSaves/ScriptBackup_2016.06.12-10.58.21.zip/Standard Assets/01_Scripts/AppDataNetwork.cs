#region Notes
/// <summary>
/// Version - 1.0
/// Created - 2012-05-11, JAC
/// LastMod - 2012-05-14, JAC
/// 
/// USAGE:
/// In order for this to work, this MonoBehaviour needs to be attacted to a GameObject 
/// in the scene, and that GameObject also has to have a NetworkView component included.
/// 
/// DESCRIPTION:
/// This enables AppData Key/Value pairs to be synchronized across networked instances.
/// 
/// CHANGE LOG:
/// 1.0
/// Added System.Boolean to the available synchronizable options.
/// 
/// Beta 1.1
/// Initial split from AppData.
/// 
/// </summary>
#endregion
using UnityEngine;
using System.Collections.Generic;

[RequireComponent  (typeof (NetworkView)) ]
public class AppDataNetwork : MonoBehaviour
{
    #region Unity Fields
    public bool SynchronizeUpdates = true;
    public string RemoteIP = "127.0.0.1";
	const string DefaultLocalIP = "127.0.0.1";
    public int ListenAndRemotePort = 1998;
    public int ServerMaxConnections = 32;
    public bool ServerUseNAT = false;
	public NetworkView NetView = null;
	
	public List<string> KeysToIgnore = new List<string>();
    #endregion

	#region Properties
    public string LocalIP
    {
        get
        {
            string Ret = "127.0.0.1";
	        if (Network.peerType != NetworkPeerType.Disconnected) { Ret = Network.player.ipAddress; }
            return Ret;
        }
    }
	
	    public bool isIPDefault
    {
        get
        {
			bool Ret = false;
			string tempIP = DefaultLocalIP;
           	if (Network.peerType != NetworkPeerType.Disconnected) {tempIP = Network.player.ipAddress; }
			if(tempIP == DefaultLocalIP){Ret = true;}
            return Ret;
        }
    }
	#endregion

	#region Unity Events
	void Awake()
	{
		if (AppData.SynchToNetwork != null)
		{
			Debug.LogError("Cannot have more than one AppDataNetwork in a scene!");
			Destroy(this, 200);
			return;
		}
		
		AppData.SynchToNetwork = this;
		NetView = GetComponent<NetworkView>();
	}
	
	/// <summary>
	/// When a client connects, send them an update of the current state of StoredValues
	/// </summary>
	/// <param name='player'>Player</param>
	void OnPlayerConnected(NetworkPlayer NewClient)
	{
		object OneValue;
		foreach (System.Collections.Generic.KeyValuePair<string, object> kvp in AppData.StoredValues)
		{
			OneValue = kvp.Value;
			if (OneValue == null) { OneValue = "HighImpact.NULL"; }
			if (AppData.GoodRPCType(OneValue.GetType())) { SendToNetwork(kvp.Key, OneValue, NewClient); }
		}
	}
	#endregion
	
	#region Networking
	#region RPC
    [RPC]
    void ValueUpdatedString(string UpdatedKey, string UpdatedValue, string ValueType)
	{
		if (UpdatedValue == null || UpdatedValue == "HighImpact.NULL")
		{
			ValueUpdatedFinal(UpdatedKey, null);
		}
		else
		{
			ValueUpdatedFinal(UpdatedKey, UpdatedValue);
		}
	}
	
	[RPC]
	void ValueUpdatedSingle(string UpdatedKey, float UpdatedValue, string ValueType)
	{
		ValueUpdatedFinal(UpdatedKey, UpdatedValue);
	}

	[RPC]
    void ValueUpdatedInt32(string UpdatedKey, int UpdatedValue, string ValueType)
	{
		switch (ValueType)
		{
		case "System.Int32":
			ValueUpdatedFinal(UpdatedKey, UpdatedValue);
			break;
		case "System.Boolean":
			bool OrigBool = UpdatedValue == 1 ? true : false;
			ValueUpdatedFinal(UpdatedKey, OrigBool);
			break;
		default:
			// Something based on System.Enum
			System.Enum OrigEnum = (System.Enum)System.Activator.CreateInstance(System.Type.GetType(ValueType));
			OrigEnum = (System.Enum)System.Enum.Parse(OrigEnum.GetType(), UpdatedValue.ToString());
			ValueUpdatedFinal(UpdatedKey, OrigEnum);
			break;
		}
	}
	
	[RPC]
	void ValueUpdatedNetworkPlayer(string UpdatedKey, NetworkPlayer UpdatedValue, string ValueType)
	{
		ValueUpdatedFinal(UpdatedKey, UpdatedValue);
	}
	
	[RPC]
	void ValueUpdatedNetworkViewID(string UpdatedKey, NetworkViewID UpdatedValue, string ValueType)
	{
		ValueUpdatedFinal(UpdatedKey, UpdatedValue);
	}
	
	[RPC]
	void ValueUpdatedVector3(string UpdatedKey, Vector3 UpdatedValue, string ValueType)
	{
		ValueUpdatedFinal(UpdatedKey, UpdatedValue);
	}
	
	[RPC]
	void ValueUpdatedQuaternion(string UpdatedKey, Quaternion UpdatedValue, string ValueType)
	{
		ValueUpdatedFinal(UpdatedKey, UpdatedValue);
	}
	
	public void ValueUpdatedFinal(string UpdatedKey, object UpdatedValue)
	{
		//AppData.Log("Received New Data: {0}={1}", UpdatedKey, UpdatedValue);
		AppData.SetData(UpdatedKey, UpdatedValue, true, false);
    }
	
	public void SendToNetwork(string UpdatedKey, object UpdatedValue)
	{
		SendToNetwork(UpdatedKey, UpdatedValue, Network.player);
	}
	
	public void SendToNetwork(string UpdatedKey, object UpdatedValue, NetworkPlayer OnePlayer)
	{
		if (SynchronizeUpdates && !KeysToIgnore.Contains(UpdatedKey))
        {
			string ValueType = UpdatedValue.GetType().ToString();
			if (UpdatedValue.GetType().BaseType == typeof(System.Enum))
			{
				UpdatedValue = (int)UpdatedValue;
			}
			if (UpdatedValue.GetType() == typeof(bool))
			{
				UpdatedValue = (int)((bool)UpdatedValue == true ? 1 : 0);
			}
			
			string RPCMethod = "ValueUpdated";
			string TempType = UpdatedValue.GetType().ToString();
			switch (TempType)
			{
			case "System.String":
			case "System.Single":
			case "System.Int32":
				RPCMethod += TempType.Replace("System.", "");
				break;
			case "UnityEngine.NetworkPlayer":
			case "UnityEngine.NetworkViewID":
			case "UnityEngine.Vector3":
			case "UnityEngine.Quaternion":
				RPCMethod += TempType.Replace("UnityEngine.", "");
				break;
			default:
				Debug.Log("Type Was:" + TempType);
				break;
			}
			
			if (OnePlayer == Network.player)
			{
            	GetComponent<NetworkView>().RPC(RPCMethod, RPCMode.Others, UpdatedKey, UpdatedValue, ValueType);
			}
			else
			{
				GetComponent<NetworkView>().RPC(RPCMethod, OnePlayer, UpdatedKey, UpdatedValue, ValueType);
			}
        }
	}
	#endregion
	
	#region Connections
    public bool ConnectToServer() { return ConnectToServer(RemoteIP, ListenAndRemotePort); }

    public bool ConnectToServer(string ServerIP, int ServerPort)
    {
        bool Ret = true;

        if (Network.peerType != NetworkPeerType.Disconnected) { Network.Disconnect(200); }

        NetworkConnectionError ConnError = Network.Connect(ServerIP, ServerPort);

        if (ConnError != NetworkConnectionError.NoError)
        {
            Ret = false;
            AppData.RecordError(string.Format("Error connecting to server: {0}", ConnError.ToString()));
        }
		else if (Network.peerType == NetworkPeerType.Disconnected)
		{
			Ret = false;
		}

        return Ret;
    }

    public bool StartServer() { return StartServer(ListenAndRemotePort, ServerMaxConnections, ServerUseNAT); }

    public bool StartServer(int ListenPort, int MaxConnections, bool UseNAT)
    {
        bool Ret = true;

        if (Network.peerType != NetworkPeerType.Disconnected) { Network.Disconnect(200); }

        NetworkConnectionError ConnError = Network.InitializeServer(MaxConnections, ListenPort, UseNAT);

        if (ConnError == NetworkConnectionError.NoError) { OnConnectedToServer(); }
        else
        {
            Ret = false;
            AppData.RecordError(string.Format("Error starting server: {0}", ConnError.ToString()));
        }

        return Ret;
    }
	
	public void Disconnect()
	{
		if (Network.peerType != NetworkPeerType.Disconnected) { Network.Disconnect(200); }
	}

    protected void OnConnectedToServer()
    {
        foreach (GameObject GO in FindObjectsOfType(typeof(GameObject)))
        {
            GO.SendMessage("OnNetworkLoadedLevel", SendMessageOptions.DontRequireReceiver);
        }
    }
	#endregion
	#endregion
}
