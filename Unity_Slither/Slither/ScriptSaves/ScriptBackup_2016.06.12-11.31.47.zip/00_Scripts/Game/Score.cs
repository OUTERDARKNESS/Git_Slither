﻿using UnityEngine;
using System.Collections;
using Food;

namespace Game
{
	public class Score : MonoBehaviour
	{
		void Awake () 
		{
			AppData.bindToData (AppDataKeys.Food_EatenParticle, Food_EatenParticle_Handler);
		}

		void OnDestroy () 
		{
			AppData.unbindToData (AppDataKeys.Food_EatenParticle, Food_EatenParticle_Handler);
		}

		void Start () 
		{
			AppData.setData (AppDataKeys.Food_EatenScore, 0);
		}	

		void Food_EatenParticle_Handler (object val) 
		{
			FoodParticle FP = (FoodParticle)val;

			int CurScore = AppData.getDataInt (AppDataKeys.Food_EatenScore);
			CurScore += FP.Calories;
			AppData.setData (AppDataKeys.Food_EatenScore, CurScore);
		}

		void OnGUI () 
		{
			GUILayout.Space (50);
			GUILayout.Box ("Score: ", GUILayout.Width(100));
			GUILayout.Box ("" + AppData.getDataInt(AppDataKeys.Food_EatenScore), GUILayout.Width(100));
		}
	}
}