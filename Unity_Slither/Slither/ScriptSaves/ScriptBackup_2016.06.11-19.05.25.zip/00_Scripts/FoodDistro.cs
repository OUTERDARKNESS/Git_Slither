﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class FoodDistro : MonoBehaviour {

	public Vector2 SceneScale = new Vector2(100, 100);
	public Vector2 FoodScale = new Vector2(0.2f, 0.5f);
	public GameObject FoodPrefab;
	public int StartFoodCount = 200;
	List<GameObject> FoodGOs = new List<GameObject>();

	void Start () 
	{
		Init ();
	}


	void Init () 
	{
		for (int i = 0; i<StartFoodCount; i++) 
		{
			AddOneFood ();
		}
	}

	void AddOneFood () 
	{
		GameObject GO = GameObject.Instantiate (FoodPrefab);
		Vector3 ThisPos = new Vector3 (Random.Range (SceneScale.x * 0.5f, SceneScale.x * -0.5f), 0.2f, Random.Range (SceneScale.y * 0.5f, SceneScale.y * -0.5f));
		GO.transform.position = ThisPos;
		Vector3 ThisScale = Vector3.one * Random.Range (FoodScale.x, FoodScale.y);
		GO.transform.localScale = ThisScale;

		GO.transform.parent = transform;

		Color ThisColor = new Color (Random.Range (0f, 1f), Random.Range (0f, 1f), Random.Range (0f, 1f), 1);
//		Renderer Rend = GO.GetComponent<Renderer> ();
//		Rend.material.color = ThisColor;

		Renderer[] Rends = GO.GetComponentsInChildren<Renderer> ();
		for (int i = 0; i < Rends.Length; i++) 
		{
			Rends [i].material.color = ThisColor;
			Rends [i].material.SetColor ("_TintColor", ThisColor);
//			if (Rends [i] != Rend) 
//			{
//				Rends [i].material.color = ThisColor;
//			}
		}




//		Light L = GO.GetComponentInChildren<Light> ();
//		L.color = ThisColor;


		FoodGOs.Add (GO);
	}

	void Update () 
	{
	
	}
}
