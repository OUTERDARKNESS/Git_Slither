﻿using UnityEngine;
using System.Collections;

public class WormFood : MonoBehaviour {

	public int FoodCount = 0;
	
	void Start () 
	{
	
	}

	void OnTriggerEnter (Collider other) 
	{
		Debug.Log ("Trigger: Hit " + other.gameObject.name + " At Time: " + Time.time);
	}
	
	void Update () 
	{
	
	}
}
