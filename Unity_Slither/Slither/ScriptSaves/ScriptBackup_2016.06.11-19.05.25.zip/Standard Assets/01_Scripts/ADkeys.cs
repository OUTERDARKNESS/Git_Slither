using UnityEngine;
using System.Collections;


public class ADkeys : MonoBehaviour
{


	//-- Level Layout
	public const string LvlLayout_SectionWidth = "LvlLayout_SectionWidth";



}
