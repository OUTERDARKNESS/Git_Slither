﻿using UnityEngine;
using System.Collections;

public class CamFollow : MonoBehaviour {

	public Transform WormTrans;
	Vector3 CurPos;
	float Elv = 0;

	void Start () 
	{
		Elv = transform.position.y - WormTrans.position.y;
	}
	
	
	void Update () 
	{
		CurPos = WormTrans.position;
		CurPos.y += Elv;
		transform.position = CurPos;
	}
}
