﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class FoodDistro : MonoBehaviour {

	public Vector2 SceneScale = new Vector2(100, 100);
	public GameObject FoodPrefab;
	public int StartFoodCount = 200;
	List<GameObject> FoodGOs = new List<GameObject>();

	void Start () 
	{
		Init ();
	}


	void Init () 
	{
		for (int i = 0; i<StartFoodCount; i++) 
		{
			AddOneFood ();
		}
	}

	void AddOneFood () 
	{
		GameObject GO = GameObject.Instantiate (FoodPrefab);
		Vector3 ThisPos = new Vector3 (Random.Range (SceneScale.x * 0.5f, SceneScale.x * -0.5f), 0, Random.Range (SceneScale.y * 0.5f, SceneScale.y * -0.5f));
		GO.transform.position = ThisPos;
		GO.GetComponent<Renderer> ().material.color = new Color (Random.Range (0f, 1f), Random.Range (0f, 1f), Random.Range (0f, 1f), 1);
		FoodGOs.Add (GO);
	}

	void Update () 
	{
	
	}
}
