﻿using UnityEngine;
using System.Collections;

public class Score : MonoBehaviour
{
	void Awake () 
	{
		AppData.bindToData (ADkeys.Food_EatenParticle, Food_EatenParticle_Handler);
		AppData.bindToData (ADkeys.Food_EatenScore, Food_EatenScore_Handler);
	}

	void OnDestroy () 
	{
		AppData.unbindToData (ADkeys.Food_EatenParticle, Food_EatenParticle_Handler);
		AppData.unbindToData (ADkeys.Food_EatenScore, Food_EatenScore_Handler);
	}

	void Start () 
	{
		AppData.setData (ADkeys.Food_EatenScore, 0);
	}	
	
	void Food_EatenParticle_Handler (object val) 
	{
		FoodParticle FP = (FoodParticle)val;

		int CurScore = AppData.getDataInt (ADkeys.Food_EatenScore);
		CurScore += FP.Calories;
		AppData.setData (ADkeys.Food_EatenScore, CurScore);
	}

	void Food_EatenScore_Handler (object val) 
	{
		int FP = (int)val;
	}

	void OnGUI () 
	{
		GUILayout.Space (50);
		GUILayout.Box ("Score: ", GUILayout.Width(100));
		GUILayout.Box ("" + AppData.getDataInt(ADkeys.Food_EatenScore), GUILayout.Width(100));
	}
}