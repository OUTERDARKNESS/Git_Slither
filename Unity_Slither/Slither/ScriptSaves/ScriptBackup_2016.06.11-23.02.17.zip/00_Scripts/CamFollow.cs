﻿using UnityEngine;
using System.Collections;

public class CamFollow : MonoBehaviour
{
	public Transform WormTransform;
	Vector3 CurrentPosition;
	float Elevation = 0;

	void Start () 
	{
		Elevation = transform.position.y - WormTransform.position.y;
	}
	
	void Update () 
	{
		CurrentPosition = WormTransform.position;
		CurrentPosition.y += Elevation;
		transform.position = CurrentPosition;
	}
}