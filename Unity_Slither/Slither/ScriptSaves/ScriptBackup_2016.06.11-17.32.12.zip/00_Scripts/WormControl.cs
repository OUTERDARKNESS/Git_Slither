﻿using UnityEngine;
using System.Collections;

public class WormControl : MonoBehaviour {


	float input_Horz = 0;
	float input_Vert = 0;

	public float Speed = 1;
	public Vector3 MoveDir;
	public Vector3 CurPos;
	public Vector3 LastPos;


	public Transform SteerGO;
	public Transform SteerTargGO;


	void Start () 
	{
		LastPos = transform.position;
	}
	
	
	void Update () 
	{
		Update_UserInput ();
		Update_Movement ();
	}


	void Update_UserInput()
	{
		input_Horz = Input.GetAxis ("Horizontal");
		input_Vert = Input.GetAxis ("Vertical");
	}


	void Update_Movement()
	{
		CurPos = transform.position;


		//MoveDir = transform.localEulerAngles;

		transform.rotation = new Quaternion (input_Horz, input_Vert, 0, 1);

		//transform.localEulerAngles = MoveDir;


		CurPos = Vector3.MoveTowards(CurPos, SteerTargGO.position, Time.deltaTime * Speed);
		transform.position = CurPos;

		LastPos = transform.position;
	}



	void OnGUI () 
	{
		GUILayout.Box ("H: " + input_Horz);
		GUILayout.Box ("V: " + input_Vert);
	}

}
