﻿using UnityEngine;
using System.Collections;

public class WormControl : MonoBehaviour {


	float input_Horz = 0;
	float input_Vert = 0;

	void Start () 
	{
	
	}
	
	
	void Update () 
	{
		Update_UserInput ();
	}


	void Update_UserInput()
	{
		input_Horz = Input.GetAxis ("Horizontal");
		input_Vert = Input.GetAxis ("Vertical");

	}

	void OnGUI () 
	{
		GUILayout.Box ("H: " + input_Horz);
		GUILayout.Box ("V: " + input_Vert);
	}

}
