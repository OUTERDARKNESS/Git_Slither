﻿using UnityEngine;
using System.Collections;

namespace Worm
{
	public class SegmentController : MonoBehaviour
	{
	}
}