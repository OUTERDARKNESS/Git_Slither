﻿using System;

namespace Worm
{
	public class InputController
	{
		
	}
}

